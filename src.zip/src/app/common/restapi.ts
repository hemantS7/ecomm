export const API = {
    LOGIN: "/login/login",
    FORGOT: "/login/verifyEmail",
    RESET: "/login/reset",
    USERACTIVITY: "/user/setUserActivityStatus",
    // SET_RESET: "/login/setPassword",
    CHANGE_PASSWORD: "/login/resetPassword",
    SET_PASSWORD: "/login/setPassword",
    FIRST_TIME_LOGIN: "/login/firstTimeLogin",
    USER_LIST: "/user/getUserList",
    CREATE_USER: "/user/usersCreate",
    TAGGING: '/bot/crmChatDetail',
    MODELLIST: '/bot/getCrmDetails',
    LOGOUT: "/user/logout",
    ALLREADYLOGIN: "/login/alreadyLogin",
  ​
    MENU_LIST: "/admin/menuList",//changes made 07-11
    GET_SALUTATION_LIST_AND_GROUPLIST: "/user/getSalutationList",
  ​
    //User
    UPDATE_USER: "/user/updateUser",
    USER_DETAILS: "/user/userDetail",
    USER_SEARCH: "/user/userSearch",
    USER_CHANGE_STATUS: "/user/setUserStatus",
    USER_DELETE: "/user/deleteUser",
    USER_ASSIGN_GROUP: "/user/getUserAssignGroupDetail",
    UPDATE_USER_GROUP_DATA: "/user/updateUserAssignGroup",
  ​
    //Group
    GET_USER_ROLE: '/group/getGroupList',
    ALL_GROUP_LIST: "/group/getGroupList",
    GET_USER_PERMISSION: '/group/getUserPermission',
    CREATE_USER_GROUP: '/group/groupCreate',
    UPDATE_USER_GROUP: '/group/editGroup',
    GROUP_CHANGE_STATUS: '/group/setUserGroupStatus',
    GROUP_SEARCH: "/group/groupSearch",
    GROUP_DELETE: "/group/deleteGroup",
    GROUP_DETAIL: "/group/groupDetail",
  ​
    //Entities
    GET_CREATED_ENTITIES: '/entities/GetEntites',
    CREATE_USER_ENTITY: "/entities/CreateEtities",
    DELETE_USER_ENTITY: "/entities/DeleteEntity",
    EDIT_USER_ENTITY: "/entities/EditEntity",
    BULKUPLOAD: "/intent/bulkEntityInsert",
  ​
    //Intents
    GET_INTENTS_LIST: "/intent/GetIntentsList",
    DELETE_USER_INTENTS: "/intent/intentDelete",
    PREDEFINE_INTENT_LIST: "/predefinedIntent/getPredefinedIntentList",
    ACTIVATED_PREDEFINE_INTENT: "/predefinedIntent/activatePredefinedIntent",
    INTENNT_IDENTIFY_PHRASES: "/intent/identifyPhrases",
    GET_INTENT_GROUPS: "/intent/getIntentGroups",
    CREATE_USER_INTENTS: "/intent/createintent",
    GET_INTENT_DETAILS: "/intent/intentDetail",
    INTENT_RESPONSE_LIST: "/intent/channelResponse",
    GET_INTENT_RESPONSE_PROPERTY: "/intent/reponsePropertiesDetail",
    GET_INTENT_COLLECTION_PROPERTY: '/intent/responsePropertyCollection',
    GET_SELECTED_COLLECTION_DETAIL: '/intent/getSelectedCollectionDetail',
    UPDATE_USER_INTENTS: '/intent/updateIntent',
    SYNCDATA:'/syncdata',  
    GET_SYNC_ENTITY: '/entities/getEntitiesListforSync',
    GET_SYNC_INTENT: '/intent/getIntentsListforSync',
    SYNC_INTENT_ENTITY: '/intent/getIntentsListforSync',
  ​
    //Collection Code 
    SELECTED_COLLECTION_DATA: '/userCollection/collectionDataDetail',
    CREATE_COLLECTIONS: '/userCollection/createUserCollection',
    COLLECTION_LIST: '/userCollection/collectionList',
    INSERT_COLLECTION: '/userCollection/insertDataReq',
    CREATE_CUSTOM_COLLECTION: '/userCollection/insertIntoCustomCollection',
    UPLOAD_IMAGE: '/entities/saveImage',
    BULK_CODE: '/userCollection/bulkUpload',
    // BULK_CODE: '/intent/BulkUploadforUserCollection',
    COLLECTION_TEMPLATE_DOWNLOAD: '/userCollection/downloadTemplateForBulkUploadTest',
  
    //Configuration Code
    AGENT_CONFIG: '/agentconfiguration/getHierarchy',
    AGENT_CONFIG_UPDATE: '/agentconfiguration/updateHierarchy',
    GET_CHAT_CONFIG: '/agentconfiguration/getConfiguration',
    CHAT_CONFIG_UPDATE: '/agentconfiguration/updateConfiguration',
    BLOCKED_USER: '/login/getUserBlockList',
    APPROVE_USER_BLOCKAGE: '/login/setcustomerBlock',
    GET_REQUESTED_USER_HISTORY: '/login/getBlockUserChatDetail',
    DASHBOARDREPORT: "/agentconfiguration/agentDashboard",
    SENDINTENTFEEDBACK: "/login/intentFeedback",
    SENDAGENTFEEDBACK: "/login/agentFeedback",
    SENDLOG: "/logs/insertFrontEndLogs",
    // Reports Api Files
    AGENT_CHAT_TRANSFER_TABLE : '/reports/agentChatTransfer',
    AGENT_CSat_TABLE : '/reports/cSatData',
    AGENT_CSat_CHAT : '/reports/chatByconversationid',
    AGENT_CSat_FEEDBACK : '/reports/gettagandFeedbackbyid',
    AGENT_Sumary_Table : '/reports/getAgentSummaryReport',
    TALLY_Table : '/reports/gettallyBifurcation',
    MEDIA_TYPE_DROPDOWN : '/bot/getCrmDetails',
    OVERALL_DUMP: '/reports/getoverAlldump',
    AGENT_LISTS: '/user/getUserListAccordingly',
  ​
    PRODUCT_CATEGORY: '/JosEcommItemGrid',
    LEADS_LOGS: '/FAQreports/getLeadLogsReport',
    DUMP_REPORTS: '/FAQreports/getConversationDumpReport',
    CHAT_LOGS: '/FAQreports/getChatLogsReport',
    BOT_FAILURE: '/FAQreports/getBotFailureReport',
    GET_SCENARIO_REPORT: '/FAQreports/getTopScenarioReport',
    GET_MODULES: '/clientCreation/getDropDownValue',
    CREATE_CLIENT: '/clientCreation/createClient',
    UPLOADIMAGE: '/clientCreation/saveImage_accordingly',
    UPLOADIMAGELIST: '/clientCreation/saveImageList_accordingly',
    GET_CLIENT_DETAILS: '/clientCreation/getClientDetails',
    UPDATE_CLIENT: '/clientCreation/updateClientDetails',
    GET_CLIENTS: '/clientCreation/getClientList',
    DELETE_CLIENT: '/clientCreation/deleteClient',
  
  
    //Template
    GET_TEMPLATES_LIST :"/brodcast/TemplateList",
    ADD_TEMPLATES :"/brodcast/createTemplate",
    EDIT_TEMPLATE:"/brodcast/templateUpdate",
    DELETE_TEMPLATE:"/brodcast/templateDelete",
    TEMPLATE_DETAILS:"/brodcast/templateDetail",
    //sender
    SENDER_LIST:"/brodcast/TemplateList",
    SAVE_DATA_TEMPLATE:"/brodcast/templateSave",
    //SENDER_HISTORY_TEMPLATE:"/brodcast/templateList", 
    SENDER_HISTORY_TEMPLATE:"/brodcast/brodcasttemplateList",
  
  
  };
  ​
  ​
  ​
  export const ENVIRONMENT = {
  
    BASEURL: "https://cors-anywhere.herokuapp.com/http://test.cboinfotech.co.in/josapi/request/dataobj/Ecomm/JosEcommItemGrid"//8004
    // BASEURL: "//test.cboinfotech.co.in/josapi/request/dataobj/Ecomm",//8004
  };