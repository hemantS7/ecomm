import { Injectable, NgZone } from "@angular/core";
import { HttpClient, HttpErrorResponse, HttpHeaders } from "@angular/common/http";
import { Router } from "@angular/router";
import { map, catchError } from "rxjs/operators";
import { throwError, BehaviorSubject, Subject } from "rxjs";
import { ENVIRONMENT, API } from "../common/restapi";
// import * as crypto from 'js-sha512';
declare global {
    interface Window {
        RTCPeerConnection: RTCPeerConnection;
        mozRTCPeerConnection: RTCPeerConnection;
        webkitRTCPeerConnection: RTCPeerConnection;
    }
}

@Injectable({ providedIn: "root" })

export class AuthService {
    localIp = sessionStorage.getItem('LOCAL_IP');
    public currentUserSubject: BehaviorSubject<any> = new BehaviorSubject<any>(localStorage.getItem("currentUser"));
    public currentUser = this.currentUserSubject.asObservable();
    authToken: string;
    status_data: any;
    headers: HttpHeaders;
    deviceInfo = null;
    currentUserData = new Subject<any>();
    public logoutDone: BehaviorSubject<boolean> = new BehaviorSubject<any>(false);
    constructor(
        private http: HttpClient,
        private _router: Router)
        {}

    getAuthorizationToken() {
        this.authToken = localStorage.getItem("currentUser");
        return this.authToken;
    }

    public handleError(error: HttpErrorResponse) {
        if (error.error instanceof ErrorEvent) {
            console.error("An error occurred:", error.error.message);
        }
        return throwError({
            status: error.status,
            error: error.error,
            message: "REQUEST FAILED. PLEASE TRY AFTER SOMETIME."
        });
    }

    // Local IP Integration Start
    private ipRegex = new RegExp(/([0-9]{1,3}(\.[0-9]{1,3}){3}|[a-f0-9]{1,4}(:[a-f0-9]{1,4}){7})/);


    private getRTCPeerConnection() {
        return window.RTCPeerConnection ||
            window.mozRTCPeerConnection ||
            window.webkitRTCPeerConnection;
    }
    // Local IP Integration end


    login(form: any) {

        const payload = {
            email: form.value.email,
            password: form.value.password,
            // password: crypto.sha512(form.value.password),
            Ip: this.localIp ? this.localIp : '0.0.0.0', //vikas changes,
            browserName: this.deviceInfo.browser, loginSession: "login"
        }
        console.log("Payload for Login :: ", payload);

        return this.http.post<any>(`${ENVIRONMENT.BASEURL}${API.LOGIN}`, payload)
            .pipe(map(user => {


                //console.log("user details is", user);
                // if (user) {
                if (user.hasOwnProperty('accessToken') && user.accessToken != undefined) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    localStorage.setItem('currentUser', window.btoa(window.btoa(window.btoa(window.btoa(JSON.stringify(user))))));
                    user['inActive'] = 'N';
                    localStorage.setItem('currentUser', window.btoa(window.btoa(window.btoa(window.btoa(JSON.stringify(user))))));
                    localStorage.setItem('accessToken', user['accessToken'])
                    // let data = this._encdec.set(ENVIRONMENT.ENDDESCKEY, user);
                    // localStorage.setItem("agentUser", data);
                    // this.currentUserData.next(data);
                    // this.currentUserSubject.next(true);
                } else {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    localStorage.setItem('currentUser', window.btoa(window.btoa(window.btoa(window.btoa(JSON.stringify(user))))));
                    this.currentUserSubject.next(null);
                }
                // }
                return user;
            }));
    }

    public get currentUserValue(): any {
        return this.currentUserSubject.value;
    }

    logout() {
        this.headers = this.setHeader();
        let logoutPayload = {
            Ip: sessionStorage.getItem('LOCAL_IP'),
            browserName: "chrome",
            loginSession: "logout"
        };
        return this.http.post<any>(`${ENVIRONMENT.BASEURL}${API.LOGOUT}`, logoutPayload, { headers: this.headers })
            .pipe(
                map(res => {
                    this.currentUserSubject.next(null);
                    localStorage.clear();
                    this._router.navigateByUrl("/login");
                },
                    catchError(this.handleError)
                ));
    }

    logoutAgent() {
        localStorage.clear();
        document.cookie = "lu=; expires=Thu, 01 Jan 1970 00:00:00 UTC;";
        this.currentUserSubject.next(null);
        this.logoutDone.next(false);
        this._router.navigate(['login']);
    }

    // HTTP Request and Response Code
    checkStatus(status: string) {
        if (status == "200") {
            this.status_data = {
                message: "OK",
                errorcode: 200
            };
        } else if (status == "400") {
            this.status_data = {
                message: "Bad Request",
                errorcode: 400
            };
        } else if (status == "401") {
            this.status_data = {
                message: "Unauthorized",
                errorcode: 401
            };
            this.logout();
            return this.status_data;
        } else if (status == "403") {
            this.status_data = {
                message: "Forbidden",
                errorcode: 403
            };
        } else if (status == "404") {
            this.status_data = {
                message: "Not Found",
                errorcode: 404
            };
        } else if (status == "500") {
            this.status_data = {
                message: "Internal Server Error",
                errorcode: 500
            };
        } else if (status == "201") {
            this.status_data = {
                message: "Created",
                errorcode: 201
            };
        } else if (status == "409") {
            this.status_data = {
                message: "conflict",
                errorcode: 409
            };
        }
        return this.status_data;
    }

    getCurrentUser() {
        if (localStorage.getItem("currentUser")) {
            return (this.currentUser = JSON.parse(
                window.atob(
                    window.atob(
                        window.atob(window.atob(localStorage.getItem("currentUser")))
                    )
                )
            ));
        }
    }

    setHeader() {

        // if (localStorage.getItem("currentUser")) {
            return (this.headers = new HttpHeaders()
                .set("Company-Code", "demotest")//changes made on 13-11
                .set("Authorization", "JOSMOBILE abcxyzsdfsdrwewer53345345sdwerwer234234")//changes made on 13-11
                .set("Content-Type", "application/json"))//changes made on 13-11
                // .set("authorization", this.getCurrentUser().accessToken));
        // }

    }


    //************************ KANHAIYA CODE ************ */
    changeAgentStatus(data: any) {
        let accessToken = localStorage.getItem('accessToken');
        const payload = {
            userId: data,
        };

        return this.http.post(`${ENVIRONMENT.BASEURL}${API.USERACTIVITY}`, payload, {
            headers: new HttpHeaders()
                .set("Content-Type", "application/json")
                .set("authorization", accessToken)
        }).pipe(
            catchError(this.handleError));
    }

    getCookie(cname) {
        var name = cname + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }


    createCookie(name, value, expires, path, domain) {
        var cookie = name + "=" + escape(value) + ";";

        if (expires) {
            // If it's a date
            if (expires instanceof Date) {
                // If it isn't a valid date
                if (isNaN(expires.getTime()))
                    expires = new Date();
            }
            else
                expires = new Date(new Date().getTime() + parseInt(expires) * 1000 * 60 * 60 * 24);

            cookie += "expires=" + expires.toGMTString() + ";";
        }

        if (path)
            cookie += "path=" + path + ";";
        if (domain)
            cookie += "domain=" + domain + ";";

        document.cookie = cookie + ";SameSite=strict";
    }
    getAgentUser() {
        let dd: any = localStorage.getItem("agentUser");
        if (dd) {
            try {
                // let y = this._encdec.get(ENVIRONMENT.ENDDESCKEY, dd);
                // this.currentUser = JSON.parse(y);
                return this.currentUser;
            } catch (err) {
                console.log("Error", err);
                this.logout();
            }
        } else {
            this.logout();
        }



    }

    getCurrentUserEnc(data) {
        let dd: any = data;
        if (dd) {
            try {
                // let y = this._encdec.get(ENVIRONMENT.ENDDESCKEY, dd);
                // this.currentUser = JSON.parse(y);
                return this.currentUser;
            } catch (err) {
                console.log("Error", err);
                this.logout();
            }
        } else {
            this.logout();
        }



    }

}
