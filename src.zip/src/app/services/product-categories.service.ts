import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";

import { catchError, map } from "rxjs/operators";
import { Observable, Subject, BehaviorSubject } from "rxjs";
import { Router } from '@angular/router';
import { ENVIRONMENT, API } from '../common/restapi';
import { AuthService } from '../http-interceptors/auth.service';
import { Category, Product } from '../app.models';
// import { NotifierService } from 'angular-notifier';
// import { AuthService } from 'src/app/http-interceptors/authentication/auth.service';

// export class Data {
//   constructor(public categories: Category[],
//               public compareList: Product[],
//               public wishList: Product[],
//               public cartList: Product[],
//               public totalPrice: number,
//               public totalCartCount: number) { }
// }

@Injectable({
  providedIn: 'root'
})
export class ProductCategoriesService {
  // private headers = new HttpHeaders({ 'Content-Type': 'application/json' })
//   public Data = new Data(
//     [], // categories
//     [], // compareList
//     [],  // wishList
//     [],  // cartList
//     null, //totalPrice,
//     0 //totalCartCount
// )

  public headers: HttpHeaders;
  baseUrl = ENVIRONMENT.BASEURL;
  valuesToDerive: any;
  gettingData = new Subject<any>();
  gettingupdatedphrases = new Subject<any>();
  phraseAllData = new Subject<any>()
  this: any;
  browserDetail: RegExpMatchArray;

  private currentUserSubject: BehaviorSubject<any> = new BehaviorSubject<any>("123")
  public currentUser = this.currentUserSubject.asObservable();
  updateProfileData(user) {
    this.currentUserSubject.next(user);
  }

  constructor(private http: HttpClient, private router: Router, private authService:AuthService) {
    this.headers = this.authService.setHeader();
    // console.log(this.headers)
  }
  //this method is used for create intent list
  GetClients(data): Observable<any> {
    let accessToken = localStorage.getItem('accessToken');
    return this.http.post(this.baseUrl + `${API.GET_CLIENTS}`, data, { headers: this.headers }).pipe(
      map(res => res),
      catchError(this.authService.handleError)
    );
  }

  DeleteClient(data): Observable<any> {
    let accessToken = localStorage.getItem('accessToken');
    return this.http.post(this.baseUrl + `${API.DELETE_CLIENT}`, data, { headers: this.headers }).pipe(
      map(res => res),
      catchError(this.authService.handleError)
    );
  }




  

  // search(
  //     model: any
  // ): Observable<SearchResultsModel<ClientInvoiceGridData>> {
  //     return this.http.post<SearchResultsModel<ClientInvoiceGridData>>(
  //         `${this._uri}${this.endpoint}/search`,
  //         model
  //     )
  // }

  getCategoryDetails():Observable<any> {
    let payload = '{"entityRows":[{"PA_ID":11189,"LOGIN_PA_ID":11189}]}';

    // console.log("this header is on reports service ", payload);
    // return this.http.post(this.baseUrl + `${API.PRODUCT_CATEGORY}`, payload, { headers: this.headers })
    return this.http.post<any>(this.baseUrl, payload, { headers: this.headers })
      .pipe(map(res => res),
        catchError(this.authService.handleError)
      );
  }

//   getCategoryDetails():Observable<any> {
        
//     let _url ="http://cboservices.in/hairfact.asmx/ECOMM_ITEM_GRID";
//     let _body="sCompanyFolder=ERA&iPA_ID=1087&iLOGIN_PA_ID=1087";
    
//     let options = new HttpHeaders({ 
//         'Content-Type': 'application/x-www-form-urlencoded'
//     });

//     var _resultString =  this.http.post(_url,_body,{headers:options,responseType:"text"}).pipe(first());
   
   
//     //return this.http.post<any>(_url,_body,{headers:options});
//     return _resultString;
// }



}
